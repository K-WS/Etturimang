import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
public class Malelaud_2 {
	
	private String ruudutaht;
	private String ruudunumber;
	private HashMap taht;
	private ArrayList
	
	public String getRuudutaht() {return ruudutaht;}
	public void setRuudutaht(String ruudutaht) {this.ruudutaht = ruudutaht;}
	public String getRuudunumber() {return ruudunumber;}
	public void setRuudunumber(String ruudunumber) {this.ruudunumber = ruudunumber;}
	
}
